$(".small-img img").click(function(){
 var smoling =$(this).attr("src");
 $(".big-img img").attr("src",smoling);
 
})